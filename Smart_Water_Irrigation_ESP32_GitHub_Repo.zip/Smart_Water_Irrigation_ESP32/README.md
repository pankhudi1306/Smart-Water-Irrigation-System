# Smart Water Irrigation System

An ESP32-based smart irrigation prototype using a DHT22 temperature/humidity sensor and a capacitive soil moisture sensor. The system monitors environmental conditions and soil moisture, and can control a pump through a relay when the soil is dry.

> **Important:** Update the GPIO pins, moisture calibration values, and relay polarity to match your actual hardware before powering the system. This repository is a starter template; verify it against your final circuit.

## Features

- Reads soil moisture from a capacitive sensor (analog output).
- Reads temperature and relative humidity from a DHT22.
- Prints readings and irrigation status to the Serial Monitor.
- Controls a pump through a relay based on soil moisture.
- Uses separate dry/wet thresholds (hysteresis) to avoid rapid relay switching.

## Hardware

- ESP32 development board
- DHT22 temperature and humidity sensor
- Capacitive soil moisture sensor (analog output)
- Relay module suitable for the pump
- Water pump and appropriate power supply
- Jumper wires and breadboard

## Example wiring

| Component | ESP32 pin (example) |
|---|---|
| DHT22 DATA | GPIO 4 |
| Capacitive soil sensor AO | GPIO 34 |
| Relay IN | GPIO 26 |
| Sensor VCC/GND | Follow the sensor's voltage requirements and share ground where appropriate |

GPIO numbers are examples. Check your actual wiring before uploading.

### Electrical safety

- Do **not** power a pump directly from an ESP32 GPIO.
- Use a properly rated relay/driver and a separate supply appropriate for the pump.
- Be careful with mains-powered pumps; use a low-voltage pump for a student prototype unless supervised by a qualified person.
- Keep water away from the ESP32 and other exposed electronics.

## Software setup

1. Install the Arduino IDE.
2. Install ESP32 board support using the Arduino IDE Boards Manager.
3. Install the **DHT sensor library** by Adafruit and its dependency **Adafruit Unified Sensor**.
4. Open `src/smart_irrigation.ino`.
5. Select your ESP32 board and COM/serial port.
6. Update the pins and calibration constants.
7. Upload and open Serial Monitor at **115200 baud**.

## Calibrating soil moisture

Capacitive sensors often return different raw values depending on the sensor, soil, and supply voltage.

1. Record the raw reading with the sensor in dry soil/air.
2. Record the raw reading in thoroughly moist soil (avoid submerging electronics).
3. Set `DRY_RAW` and `WET_RAW` in the sketch to those values.
4. Check the displayed percentage against real soil conditions.

The percentage is an approximate normalized reading, not a laboratory measurement.

## Irrigation behavior

- When the soil reading falls below the dry threshold, the pump turns on.
- When the soil reaches the wet threshold, the pump turns off.
- DHT22 temperature and humidity are displayed for environmental monitoring. In this starter version, soil moisture is the irrigation control input.

## Repository structure

```text
Smart_Water_Irrigation_ESP32/
├── README.md
├── LICENSE
├── .gitignore
└── src/
    └── smart_irrigation.ino
```

## Future improvements

- Add a display or web dashboard.
- Add data logging and historical charts.
- Add alerts for low water level in the tank.
- Add configurable irrigation thresholds.

## License

This project is released under the MIT License. See `LICENSE`.
