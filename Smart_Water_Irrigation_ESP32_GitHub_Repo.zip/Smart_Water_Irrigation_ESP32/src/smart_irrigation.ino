/*
  Smart Water Irrigation System
  ESP32 + DHT22 + Capacitive Soil Moisture Sensor + Relay/Pump

  Starter template: confirm GPIOs, sensor calibration, relay polarity,
  and pump driver hardware before use.
*/

#include <DHT.h>

// ---------- Pin configuration (EDIT TO MATCH YOUR CIRCUIT) ----------
#define DHT_PIN       4
#define DHT_TYPE      DHT22
#define SOIL_PIN      34       // ESP32 ADC input-only pin (example)
#define RELAY_PIN     26

// Many relay boards are active LOW. Change if your relay is active HIGH.
#define RELAY_ACTIVE_LOW true

// ---------- Soil moisture calibration (EDIT AFTER CALIBRATION) ----------
const int DRY_RAW = 3000;      // Example raw value in dry soil
const int WET_RAW = 1400;      // Example raw value in moist soil

// Hysteresis thresholds: pump turns ON below dry threshold,
// and turns OFF at/above wet threshold.
const int PUMP_ON_BELOW_PERCENT  = 35;
const int PUMP_OFF_ABOVE_PERCENT = 55;

// Safety timeout: limits a single continuous pump run.
const unsigned long MAX_PUMP_RUN_MS = 30UL * 1000UL;

DHT dht(DHT_PIN, DHT_TYPE);

bool pumpOn = false;
unsigned long pumpStartTime = 0;

void setPump(bool on) {
  pumpOn = on;

  if (RELAY_ACTIVE_LOW) {
    digitalWrite(RELAY_PIN, on ? LOW : HIGH);
  } else {
    digitalWrite(RELAY_PIN, on ? HIGH : LOW);
  }
}

int readSoilRaw() {
  // Average a few readings to reduce noise.
  long total = 0;
  const int samples = 10;

  for (int i = 0; i < samples; i++) {
    total += analogRead(SOIL_PIN);
    delay(10);
  }

  return total / samples;
}

int soilPercentFromRaw(int raw) {
  // Works whether the raw dry value is higher or lower than wet value.
  long percent = map(raw, DRY_RAW, WET_RAW, 0, 100);
  return constrain((int)percent, 0, 100);
}

void setup() {
  Serial.begin(115200);

  pinMode(RELAY_PIN, OUTPUT);
  setPump(false); // Ensure pump starts OFF

  analogReadResolution(12); // ESP32 ADC: typically 0–4095
  dht.begin();

  Serial.println();
  Serial.println("Smart Water Irrigation System starting...");
}

void loop() {
  int soilRaw = readSoilRaw();
  int soilPercent = soilPercentFromRaw(soilRaw);

  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  Serial.println("--------------------------------");
  Serial.print("Soil raw: ");
  Serial.println(soilRaw);
  Serial.print("Estimated soil moisture: ");
  Serial.print(soilPercent);
  Serial.println("%");

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("DHT22 read failed. Check wiring.");
  } else {
    Serial.print("Temperature: ");
    Serial.print(temperature);
    Serial.println(" °C");

    Serial.print("Humidity: ");
    Serial.print(humidity);
    Serial.println(" %");
  }

  // Soil-moisture-based irrigation with hysteresis.
  if (!pumpOn && soilPercent < PUMP_ON_BELOW_PERCENT) {
    setPump(true);
    pumpStartTime = millis();
    Serial.println("Soil is dry: pump ON");
  } else if (pumpOn && soilPercent >= PUMP_OFF_ABOVE_PERCENT) {
    setPump(false);
    Serial.println("Soil moisture sufficient: pump OFF");
  }

  // Fail-safe: stop pump if it runs continuously for too long.
  if (pumpOn && (millis() - pumpStartTime >= MAX_PUMP_RUN_MS)) {
    setPump(false);
    Serial.println("Safety timeout reached: pump OFF");
  }

  Serial.print("Pump status: ");
  Serial.println(pumpOn ? "ON" : "OFF");

  delay(2000);
}
